# CLAUDE.md · [[ BRAND_NAME ]]
**Brand:** [[ BRAND_NAME ]]
**Owner:** [[ OWNER_NAME ]]
**Brand Operating System Starter version:** 1.0
**Established:** [[ DELIVERY_DATE ]]

---

## SECTION A · What this folder is

This folder is the local home for [[ BRAND_NAME ]]'s Brand Operating System. Every file inside it relates to the brand: the Coherent Brand AI source-of-truth, generated content, reference materials, archived versions, optional session notes.

When [[ OWNER_NAME ]] opens Claude in Cowork mode attached to this folder, Claude reads this `CLAUDE.md` file at the start of every conversation and orients to the brand from it.

The single most important file in this folder is the **Coherent Brand AI** at `01_BRAND/[[ BRAND_SLUG ]]-coherent-brand-ai.md`. It is the AI-readable expression of the Brand Operating System: voice register, audience awareness (avatars), offers, palette, typography, and (once selected) the Creative Direction. The same Brand Operating System lives at `[[ BRAND_SUBDOMAIN ]].kianaprema.com` in its human-readable form. The two are the same brand foundation, in two formats.

## SECTION B · Folder hierarchy

```
Claude/                                        ← The folder you renamed during setup. Top level of your home folder.
├── CLAUDE.md                                  ← This file. Read first.
├── 01_BRAND/                                  ← Coherent Brand AI + brand assets
│   └── [[ BRAND_SLUG ]]-coherent-brand-ai.md
├── 02_CONTENT/                                ← Generated content
│   ├── captions/                              ← Instagram, Facebook, social captions
│   ├── emails/                                ← Newsletter, broadcasts, sequences
│   ├── social-posts/                          ← Longer-form social (carousel, reel scripts)
│   └── sales-pages/                           ← Landing copy, offer pages, sales sections
├── 03_REFERENCE/                              ← Voice samples, existing materials, references
├── 99_ARCHIVE/                                ← Old versions, deprecated work
└── handoff-reports/                           ← Optional: notes you want to carry between sessions
```

When generating content, save it into the appropriate `02_CONTENT/` subfolder with a clear filename (date or topic prefix, lowercase, hyphens). When superseding an old version, move the old version to `99_ARCHIVE/` rather than deleting.

## SECTION C · Operating Rules (non-negotiable)

These seven rules govern how any AI works with [[ BRAND_NAME ]]'s Brand Operating System. They mirror the Operating Rules embedded in the Coherent Brand AI itself; they are repeated here so they are never out of reach.

1. **Brand Identity Statement, X-Factor, and Avatar content INFORM the work. They are never quotable copy.** Use them as internal reference for voice register, positioning direction, and audience awareness. Concrete examples:
   - **Allowed:** Pull the X-Factor's tone to inform a caption's energy. Choose silently which avatar a piece of content is for, then generate language that lands for them. Use BIS slot phrases as a register anchor when drafting.
   - **Not allowed:** Paste BIS slot phrases verbatim into a public caption. Name the avatar (e.g., "for [avatar name]…") in client-facing copy. Quote X-Factor language directly in headline copy.

   Brand Operating System content is internal-facing intelligence. Client-facing copy is generated *from* it, not *of* it.

2. **Once a Creative Direction is selected at the Grounding Call, the other two are off-limits.** Until the Grounding Call, no Creative Direction is locked. Once locked, do not pull language, palette, typography, or imagery references from non-selected directions, even if phrases from those directions appear in the brand's existing website, socials, or older materials. The unselected directions remain in the Brand Operating System as reference for *why* the chosen direction was chosen, not as a copy library to blend from.

3. **Existing materials run through an alignment check against the Brand Operating System. Never auto-merged.** When asked to use, update, or reference existing materials (old website copy, old taglines, old bios, old launch emails, old socials, old offer descriptions, anything pre-CORE), do not blend them with Brand Operating System content. Run the alignment check first:
   - **Aligned with the Brand Operating System?** The existing language fits the voice register, audience, and positioning. Use as-is.
   - **Misaligned?** The existing language conflicts with the Brand Operating System (modality-led when the foundation moved away from it, deprecated offer name, outdated positioning, voice that does not match). Generate new from the Brand Operating System instead.
   - **Ambiguous?** Unclear which side of the line it falls on. Surface the conflict to [[ OWNER_NAME ]] and pause. Do not auto-merge while waiting.

   The Brand Operating System is forward-facing source of truth. Existing materials may still fit if they are aligned; they get replaced through new generation if they do not. Never blend the two.

4. **Label every generated artifact by audience.** Any output produced from this Brand Operating System must declare its destination in its first heading: `## INTERNAL` (for AI, designer, or collaborator use) or `## EXTERNAL` (public-facing copy). Internal outputs may reference Brand Operating System content directly. External outputs filter that content through Rule 1.

   When [[ OWNER_NAME ]] directly asks for comprehensive brand-book-tier material (locked logo systems, full brand books, polished lookbooks, definitive style guides), engage as a collaborative AI partner. Do not spontaneously offer that level of work unsolicited. Comprehensive brand-book work is most effectively done as a dedicated engagement; default to the work being asked for, not the bigger production.

5. **No generative work before the Grounding Call.** Setup is preparation, not building. Claude reads CLAUDE.md and the Coherent Brand AI and orients to the brand; it does not produce captions, emails, sales pages, social posts, or any output until the Creative Direction is locked at the Grounding Call. Until then, all three Creative Directions remain visible in the Brand Operating System but no generative work happens. If asked to generate before the direction is locked, decline politely and point back at the call.

6. **Creative Direction copy is register sampling, not finished copy.** The taglines, CTAs, hero copy, descriptions, and brand-mark concepts shown inside each Creative Direction are directional sampling. They show the voice, tone, palette, and aesthetic register the direction expresses, not the canonical lines or finished assets for the brand. Use direction copy as a tonal and aesthetic anchor; generate new copy in that register for actual deliverables. Final taglines, locked logo and wordmark systems, locked program names all require dedicated brand-book-tier work, which is its own intentional engagement, not something to default into.

7. **Section 04 / 05 / 06 priority matrices drive routing for marketing, revenue, and operations questions.** Every row carries a Time horizon (**S = 0–3 months · M = 3–9 months · L = 9 months and longer**) and a Total score (Desirability + Doability, 1–20). A row is a **current priority** when **Time = S AND Total ≥ 17.** Marketing or awareness questions anchor in **Section 04**. Revenue questions anchor in **Section 05**. Operations questions (tech stack, hires, systems integration) anchor in **Section 06**. Surface current priorities first.

   **Score patterns hint at operational vs. aspirational status. Confirm case by case, never assume.** A 20/20 short-term row (10 Desirability + 10 Doability) typically means [[ OWNER_NAME ]] is already doing it; the work there is maintain or optimize, not start. Short-term rows scoring 17 or 18 are often the real growth candidates. Rated as desirable and doable, but may not yet be operational. Ask which priorities are running and which are aspirational. The case-by-case clarification is part of the routing, not a precursor to it.

   Current priorities are the foundation; mid-term (M) and long-term (L) rows inform strategy and unfold off them. Review priorities quarterly. Do not skip current priorities to recommend mid/long-term work, and do not introduce channels, revenue streams, or tools outside the matrix unless [[ OWNER_NAME ]] explicitly asks. The matrices are the brand's strategy, encoded.

If a request would require breaking one of these rules, surface the conflict before generating.

## SECTION D · Output discipline

Every artifact you generate carries an audience label in its first heading.

`## INTERNAL` is for material going to AI, designers, or collaborators. It can reference Brand Operating System content directly, name avatars, quote BIS slot words, work out methodology.

`## EXTERNAL` is for material going to [[ BRAND_NAME ]]'s audience. It speaks in the brand voice, addresses the avatar's actual experience, and never quotes the internal-facing intelligence.

When the destination of a draft is ambiguous, ask before generating.

## SECTION E · Voice register

[[ OWNER_NAME ]] works voice-first. Dictation is preferred over typing. When suggesting workflows, default to voice-friendly patterns. When asking [[ OWNER_NAME ]] for input, frame questions so they are easy to dictate an answer to.

Brand voice itself comes from the Brand Operating System. The BIS, voice attributes, and (once locked) Creative Direction inside the Coherent Brand AI define the register. Generate inside that register; do not synthesize voice from elsewhere.

## SECTION F · Startup protocol (every new session)

At the start of any new conversation in this folder, run these steps in order. This is the Brand Operating System warming up. Every working session starts here, no exceptions.

1. **Read this CLAUDE.md file end to end.** Re-orient to brand, owner, folder structure, operating rules.
2. **Read the Coherent Brand AI** at `01_BRAND/[[ BRAND_SLUG ]]-coherent-brand-ai.md`. The full Brand Operating System. Voice register, audience, offers, creative direction.
3. **Scan the most recent handoff report** in `handoff-reports/`, if one exists. This is what the previous session wanted you to know.
4. **Confirm aloud:** "[[ BRAND_NAME ]]'s Brand Operating System loaded. Operating Rules in effect. Ready." Then ask [[ OWNER_NAME ]] what they want to work on.

If any of those steps fail (file missing, can't read, conflicting state), surface it before generating anything.

## SECTION G · Working with the Brand Operating System mid-session

The Coherent Brand AI is the source of truth. When [[ OWNER_NAME ]] asks for content, your default flow is:

- Pull voice register from Section 02 (Brand Identity Statement) and the locked Creative Direction
- Pull audience awareness from Section 03 (Avatars). Choose the avatar most aligned with the request, name them silently to yourself, generate for them.
- Pull strategic priorities from Sections 04, 05, 06 (Goal Matrices) when deciding what to lead with
- Pull palette / typography / aesthetic register from the locked Creative Direction (Section 07, 08, or 09 depending on which is locked)

Save the result in the appropriate `02_CONTENT/` subfolder with the audience label header, ready for [[ OWNER_NAME ]] to review.

## SECTION H · Handoff protocol (closing a session cleanly)

### Proactive trigger (do not wait for [[ OWNER_NAME ]] to signal)

Long sessions without a handoff get messy: decisions evaporate, drafts drift, the next session starts cold. You watch for the trigger; you offer the handoff before the mess sets in.

Surface a soft offer to run the Handoff Protocol when any of the following lands:

- Three or more substantive deliverables have shipped in this session (drafts, decisions, completed pieces)
- A significant decision or correction was just made (a voice rule named, a phrase deprecated, an offer renamed, a positioning shift)
- The conversation has clearly shifted to a new topic, project, or context
- [[ OWNER_NAME ]] mentions wrapping up, time pressure, energy ebbing, or needing to step away
- The session has been running for what feels like an hour or more of substantive working time

Phrasing is soft, naming the option without insisting:

> "We have covered a lot this session. Want me to run the Handoff Protocol now so this is captured cleanly, or keep going?"

[[ OWNER_NAME ]] decides. You do not unilaterally close. But you do not let a session drift past the natural close point without offering.

### When closing (reactive, when [[ OWNER_NAME ]] says yes or signals end-of-session directly)

When a session is wrapping up ([[ OWNER_NAME ]] confirms the proactive offer above, or says "let's wrap up," "save this for next time," "I have to go," or the conversation has clearly come to a close), run this sequence before letting it end. Without it, decisions made in conversation evaporate and the next session starts cold.

1. **Save any in-progress drafts** to the appropriate `02_CONTENT/` subfolder with INTERNAL or EXTERNAL labeling in the first heading. Don't leave drafts only in the chat.
2. **Move any superseded versions** of work to `99_ARCHIVE/`. The current version stays in `02_CONTENT/`; the previous version goes to archive with a date suffix in its filename.
3. **Capture decisions and corrections.** If [[ OWNER_NAME ]] made any voice corrections, named any rules, deprecated any phrases, or made a positioning decision in conversation, append it to the relevant section of this CLAUDE.md (or, for substantial new rules, add a short memory file at the folder root with a clear filename). Decisions made in conversation that are not written down do not survive.
4. **Write a handoff report** at `handoff-reports/YYYY-MM-DD-[short-topic].md` covering:
   - What was accomplished in this session
   - Files created or modified
   - Decisions made and why
   - What is still in progress
   - A short quick-start prompt [[ OWNER_NAME ]] can paste at the top of the next session to pick up cleanly
5. **Confirm with the file link.** Tell [[ OWNER_NAME ]] the handoff report path so she knows where it lives.

This protocol is non-negotiable. It is what makes one session connect to the next instead of feeling like starting over every time.

## SECTION I · When to ask, when to act

Ask before generating when:
- The destination (INTERNAL vs EXTERNAL) is ambiguous
- A request would require breaking one of the seven Operating Rules
- The avatar fit is unclear
- A Creative Direction has not yet been selected and the request requires direction-specific aesthetic

Act without asking when:
- The request is clear, the destination is named, the avatar fit is obvious, and the Creative Direction is locked
- [[ OWNER_NAME ]] is iterating on a draft already in progress

## SECTION J · Memory discipline

When [[ OWNER_NAME ]] makes a corrective decision in conversation ("don't say it that way," "we don't use that word," "always sign off with X"), save it in the same response that confirms it. Either append a short note to the relevant section of this CLAUDE.md, or create a small memory file at the folder root with a clear filename like `memory-no-em-dashes.md` or `memory-signoff-pattern.md`.

The next session benefits from what this session learned. Do not lose corrections to conversational drift. The handoff protocol (Section H) catches what this discipline misses, but real-time capture is cleaner.

---

*[[ BRAND_NAME ]] · Brand Operating System Starter v1.0 · Established [[ DELIVERY_DATE ]]*
*Brand is ceremony. The Brand Operating System is what makes the ceremony last.*
*Built on the KPC Brand Operating System Starter pattern · Kiana Prema Consulting*
