# 03_REFERENCE

Reference material lives here. Voice samples, existing pre-CORE materials, inspiration clippings, anything that informs the work without being the official brand identity.

**What goes here:**
- Voice samples (your own past writing, recorded conversations, transcripts of how you actually talk)
- Existing materials from before this brand engine: old website copy, old offer descriptions, old bios, old taglines (kept for reference + reconciliation, NOT for generation)
- Inspiration clippings: writing or visuals from elsewhere that inform the register, with source attribution
- Audience research, testimonials, interview notes

**What does NOT go here:**
- The brand brief itself (that lives in `01_BRAND/` as the source of truth)
- Newly generated content (lives in `02_CONTENT/`)

**Important:** materials in this folder are NOT the source of truth. The brand brief in `01_BRAND/` is. If something in `03_REFERENCE/` conflicts with the brief, the brief wins (Operating Rule 3 in `CLAUDE.md`).
