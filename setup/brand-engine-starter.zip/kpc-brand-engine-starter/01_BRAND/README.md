# 01_BRAND

The official brand identity lives here. Drop the brand brief MD into this folder when you set up the engine; it stays here as the source of truth for everything else.

**What goes here:**
- `[[ BRAND_SLUG ]]-brand-brief.md` — your brand identity brief (downloaded from your live brief)
- Future brand assets: brand book, locked taglines, finalized avatar one-pagers, palette/typography swatch files

**What does NOT go here:**
- Generated content (that lives in `02_CONTENT/`)
- Existing pre-CORE materials, reference clippings, voice samples (those live in `03_REFERENCE/`)
- Old superseded versions (those move to `99_ARCHIVE/`)
