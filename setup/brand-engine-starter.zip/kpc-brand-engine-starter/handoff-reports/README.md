# handoff-reports

Optional. Use this folder if you want to leave notes for your future self (or for Claude in a future session) about what just happened in a working session.

**When to write a handoff report:**
- After a substantive working session where decisions were made
- Before stepping away from work-in-progress that will be resumed later
- When a session surfaces a learning that should carry forward

**Format:** date-prefixed markdown file with a clear topic. Example: `2026-05-15-handoff-launch-week-captions-decisions.md`.

**What to include:**
- What was accomplished in the session
- Decisions made (and the why)
- What is still in progress
- A short "quick-start prompt" you can paste into the next session to pick up where you left off

Skip this folder entirely if it does not serve your workflow. It is here for when you need it.
