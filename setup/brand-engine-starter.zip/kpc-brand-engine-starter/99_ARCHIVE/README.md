# 99_ARCHIVE

Old versions and deprecated work live here. When superseding a draft, move the old version into this folder rather than deleting it. Past work informs future work.

**What goes here:**
- Old versions of generated content (e.g., a v1 caption replaced by v2)
- Deprecated brand decisions (a tagline you decided against, an offer name that got renamed)
- Past project materials no longer in active use

**Convention:** keep the original filename and add a date suffix or subfolder. Example: `99_ARCHIVE/2026-05/launch-week-caption-v1.md`.

Never delete; always archive. The reasoning behind a past decision often matters again later.
