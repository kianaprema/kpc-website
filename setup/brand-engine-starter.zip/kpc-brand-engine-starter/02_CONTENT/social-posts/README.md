# social-posts

Longer-form social content. Carousel scripts, reel scripts, LinkedIn posts, threaded posts.

**Naming:** `YYYY-MM-DD-short-topic.md`
**First heading:** `## EXTERNAL` (public-facing copy) or `## INTERNAL` (script notes / outline for content yet to be filmed or assembled)
