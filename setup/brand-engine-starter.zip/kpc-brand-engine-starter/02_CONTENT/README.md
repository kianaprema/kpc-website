# 02_CONTENT

Generated content lives here, organized by surface. Each subfolder holds drafts and final versions for that surface.

**Subfolders:**
- `captions/` — Instagram, Facebook, social captions (anywhere a caption ships under an image or video)
- `emails/` — Newsletter broadcasts, sequences, one-off sends
- `social-posts/` — Longer-form social (carousel scripts, reel scripts, LinkedIn posts)
- `sales-pages/` — Landing copy, offer pages, sales sections, full sales letters

**Naming convention:** date-prefixed, hyphenated, all lowercase. Example: `2026-05-15-launch-week-caption.md` or `2026-06-01-newsletter-becoming-44.md`.

**Audience labeling:** every file's first heading is `## INTERNAL` or `## EXTERNAL` (per Operating Rule 4 in `CLAUDE.md`). External outputs are public-facing copy. Internal outputs are designer/collaborator briefs, methodology notes, working drafts.

When superseding an old version, move the old version to `99_ARCHIVE/` rather than deleting.
