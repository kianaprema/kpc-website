# emails

Newsletter broadcasts, sequences, one-off sends. Anything that ships in a subscriber's inbox.

**Naming:** `YYYY-MM-DD-short-topic.md`
**First heading:** `## EXTERNAL` (public-facing copy) or `## INTERNAL` (briefing notes for an email yet to be drafted)
