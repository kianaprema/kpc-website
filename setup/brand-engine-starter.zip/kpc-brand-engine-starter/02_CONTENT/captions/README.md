# captions

Instagram, Facebook, and other social-feed captions. Anywhere a caption ships under an image or video, save it here.

**Naming:** `YYYY-MM-DD-short-topic.md`
**First heading:** `## EXTERNAL` (these are public-facing copy)
