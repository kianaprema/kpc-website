# sales-pages

Landing-page copy, offer-page copy, sales-section copy, full sales letters.

**Naming:** `YYYY-MM-DD-offer-name-section.md` or `YYYY-MM-DD-offer-name-full.md`
**First heading:** `## EXTERNAL` (public-facing copy) or `## INTERNAL` (architectural / strategic notes about a sales page in development)
